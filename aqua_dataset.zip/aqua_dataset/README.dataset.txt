# Aquatic animals > 2023-10-19 11:21pm
https://universe.roboflow.com/iiitdm-kurnool-gqcnn/aquatic-animals-suqmw

Provided by a Roboflow user
License: CC BY 4.0

